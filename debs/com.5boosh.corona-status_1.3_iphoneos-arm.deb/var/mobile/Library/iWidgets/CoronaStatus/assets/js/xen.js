function mainUpdate(type) {
	document.getElementById('left_top').addEventListener('touchstart', () => {
		$('#covid_title').text("Loading..");
		$('#covid_cases').text("Loading..");
		$('#covid_deaths').text("Loading..");
		$('#covid_recoveries').text("Loading..");
		init_main();
	});
}
console.log('[HSWB] XenInfo functions initialized!');
