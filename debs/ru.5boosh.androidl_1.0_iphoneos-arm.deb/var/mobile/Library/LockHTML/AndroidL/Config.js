//Enable for 24 hour clock
var hours24 = false;

//Change weather units
var units = 'c';

//Change Location
var weatherLocation = 'Krasnoyarsk';

var woeidStatus = false;

var woeidLoc = '12597862';
