#import <UIKit/UIKit.h>

@interface NSDate (Elapsed)

- (NSString *)getElapsedTime;

@end