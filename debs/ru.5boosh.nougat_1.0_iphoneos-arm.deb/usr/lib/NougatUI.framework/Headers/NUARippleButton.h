#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

@interface NUARippleButton : UIControl

@end